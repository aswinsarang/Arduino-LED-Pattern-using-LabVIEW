# Arduino-LED-Pattern-using-LabVIEW
LabVIEW project to blink LEDs in different pattern using an arduino. This project is an exercise created to understand the basic concepts of interfacing an Arduino Uno Board with LabVIEW and to understand the usage of hardware specific functions.
For queries please contact me via email : mail@aswinsarang.com
